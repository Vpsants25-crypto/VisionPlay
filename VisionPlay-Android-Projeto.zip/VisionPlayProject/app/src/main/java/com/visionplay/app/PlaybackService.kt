package com.visionplay.app
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
class PlaybackService : MediaSessionService() {
 private var session: MediaSession? = null
 override fun onCreate() {
  super.onCreate()
  val p = ExoPlayer.Builder(this).build()
  p.setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true)
  p.setHandleAudioBecomingNoisy(true)
  session = MediaSession.Builder(this, p).build()
 }
 override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session
 override fun onDestroy() {
  session?.run { player.release(); release() }
  session = null
  super.onDestroy()
 }
}
