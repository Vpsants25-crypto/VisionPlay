package com.visionplay.app
import android.content.ComponentName
import android.content.Context
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import com.google.common.util.concurrent.ListenableFuture
import org.json.JSONArray

@OptIn(ExperimentalMaterial3Api::class, UnstableApi::class)
class MainActivity : ComponentActivity() {
 private var future: ListenableFuture<MediaController>? = null
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  future = MediaController.Builder(this, SessionToken(this, ComponentName(this, PlaybackService::class.java))).buildAsync()
  setContent { VisionPlayUi(future!!) }
 }
 override fun onDestroy() { future?.let { MediaController.releaseFuture(it) }; super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class, UnstableApi::class)
@Composable
private fun VisionPlayUi(future: ListenableFuture<MediaController>) {
 val context = LocalContext.current
 val prefs = remember { context.getSharedPreferences("visionplay", Context.MODE_PRIVATE) }
 var player by remember { mutableStateOf<MediaController?>(null) }
 var url by remember { mutableStateOf("") }
 var subtitle by remember { mutableStateOf<Uri?>(null) }
 var current by remember { mutableStateOf("") }
 var title by remember { mutableStateOf("Nenhum vídeo selecionado") }
 var message by remember { mutableStateOf("Escolha um vídeo local ou use um link direto.") }
 var favorites by remember { mutableStateOf(readFavorites(prefs)) }
 var showFavorites by remember { mutableStateOf(false) }
 var fullscreen by remember { mutableStateOf(false) }

 DisposableEffect(future) {
  val listener = Runnable { try { player = future.get() } catch (_: Exception) { message = "Falha ao iniciar o player." } }
  future.addListener(listener, { it.run() })
  onDispose { }
 }
 val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
  if (uri != null) {
   try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
   loadVideo(player, prefs, uri.toString(), uri.lastPathSegment ?: "Vídeo local", subtitle) { u,t -> current=u; title=t; message="Vídeo carregado" }
  }
 }
 val subtitlePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
  if (uri != null) { subtitle=uri; message="Legenda selecionada; abra o vídeo novamente para aplicar." }
 }
 MaterialTheme(colorScheme = darkColorScheme(primary=androidx.compose.ui.graphics.Color(0xFFC6A4FF), background=androidx.compose.ui.graphics.Color(0xFF0B0B0D), surface=androidx.compose.ui.graphics.Color(0xFF19191F))) {
  Scaffold(containerColor=MaterialTheme.colorScheme.background) { pad ->
   Column(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
    Row(verticalAlignment=Alignment.CenterVertically) {
     Column(Modifier.weight(1f)) {
      Text("VISION PLAY", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Black)
      Text("Reprodutor minimalista", color=MaterialTheme.colorScheme.primary)
     }
     TextButton(onClick={showFavorites=!showFavorites}) { Text(if(showFavorites) "Voltar" else "★ Favoritos") }
    }
    if (!showFavorites) {
     if (player != null) AndroidView(Modifier.fillMaxWidth().height(if(fullscreen) 400.dp else 220.dp), factory={ ctx -> PlayerView(ctx).apply { useController=true } }, update={ it.player=player })
     else Surface(Modifier.fillMaxWidth().height(180.dp), shape=MaterialTheme.shapes.large, color=MaterialTheme.colorScheme.surface) { Box(contentAlignment=Alignment.Center) { Text("▶", style=MaterialTheme.typography.displayLarge, color=MaterialTheme.colorScheme.primary) } }
     Text(title, style=MaterialTheme.typography.titleMedium, fontWeight=FontWeight.SemiBold)
     Text(message, style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.primary)
     Button(onClick={videoPicker.launch(arrayOf("video/*"))}, modifier=Modifier.fillMaxWidth()) { Text("＋ Escolher vídeo do celular") }
     OutlinedTextField(value=url, onValueChange={url=it}, modifier=Modifier.fillMaxWidth(), label={Text("Link direto de vídeo HTTP/HTTPS")}, singleLine=true, keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Uri))
     Button(onClick={
      val v=url.trim()
      if(v.startsWith("https://") || v.startsWith("http://")) loadVideo(player,prefs,v,v.substringAfterLast('/').ifBlank{"Vídeo da internet"},subtitle) {u,t->current=u;title=t;message="Link carregado"}
      else message="Use um link direto para um arquivo de vídeo."
     }, modifier=Modifier.fillMaxWidth()) { Text("▶ Reproduzir link") }
     Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
      OutlinedButton(onClick={subtitlePicker.launch(arrayOf("*/*"))}, modifier=Modifier.weight(1f)) { Text("Legendas") }
      OutlinedButton(onClick={
       if(current.isNotBlank()) {
        val n=favorites.toMutableSet()
        if(!n.add(current)) n.remove(current)
        favorites=n; prefs.edit().putString("favorites", JSONArray(n.toList()).toString()).apply()
       } else message="Abra um vídeo primeiro."
      }, modifier=Modifier.weight(1f)) { Text(if(favorites.contains(current) && current.isNotBlank()) "★ Favoritado" else "☆ Favoritar") }
     }
     Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
      OutlinedButton(onClick={ if(current.isNotBlank()) { prefs.edit().putLong("pos_"+current.hashCode(), player?.currentPosition ?: 0L).apply(); message="Posição salva." } }, modifier=Modifier.weight(1f)) { Text("Salvar posição") }
      OutlinedButton(onClick={ if(context is ComponentActivity) { context.requestedOrientation=if(fullscreen) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE; fullscreen=!fullscreen } }, modifier=Modifier.weight(1f)) { Text(if(fullscreen) "Sair tela cheia" else "Tela cheia") }
     }
    } else {
     Text("FAVORITOS", style=MaterialTheme.typography.titleLarge, fontWeight=FontWeight.Bold)
     if(favorites.isEmpty()) Text("Ainda não há favoritos.")
     LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
      items(favorites.toList()) { item ->
       Card { Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment=Alignment.CenterVertically) {
        Text(item.substringAfterLast('/').ifBlank{item}, Modifier.weight(1f), maxLines=2)
        TextButton(onClick={loadVideo(player,prefs,item,item.substringAfterLast('/').ifBlank{"Favorito"},null){u,t->current=u;title=t;message="Favorito aberto";showFavorites=false}}) { Text("Abrir") }
        TextButton(onClick={val n=favorites.toMutableSet().apply{remove(item)};favorites=n;prefs.edit().putString("favorites",JSONArray(n.toList()).toString()).apply()}) { Text("Remover") }
       } }
      }
     }
    }
   }
  }
 }
}

@OptIn(UnstableApi::class)
private fun loadVideo(player: MediaController?, prefs: android.content.SharedPreferences, uri: String, name: String, subtitle: Uri?, onLoaded:(String,String)->Unit) {
 if(player==null) return
 val item=MediaItem.Builder().setUri(uri).setMediaMetadata(MediaMetadata.Builder().setTitle(name).build())
 if(subtitle!=null) item.setSubtitleConfigurations(listOf(MediaItem.SubtitleConfiguration.Builder(subtitle).setMimeType(if(subtitle.toString().endsWith(".srt")) MimeTypes.APPLICATION_SUBRIP else MimeTypes.TEXT_VTT).setLanguage("pt").setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()))
 player.setMediaItem(item.build())
 player.prepare()
 val pos=prefs.getLong("pos_"+uri.hashCode(),0L)
 if(pos>0) player.seekTo(pos)
 player.playWhenReady=true
 onLoaded(uri,name)
}
private fun readFavorites(prefs: android.content.SharedPreferences): Set<String> = try {
 val a=JSONArray(prefs.getString("favorites","[]")); (0 until a.length()).map{a.getString(it)}.toSet()
} catch(_:Exception){ emptySet() }
