# Vision Play — projeto Android

Projeto-fonte Android em Kotlin, com interface escura, Media3/ExoPlayer, seleção de vídeos locais, links diretos HTTP/HTTPS, favoritos, posição de reprodução salva manualmente, seleção de legendas e serviço MediaSession para suporte à reprodução em segundo plano.

## Gerar APK
1. Extraia o ZIP.
2. Abra a pasta no Android Studio.
3. Instale o Android SDK 35 se for solicitado e aguarde a sincronização do Gradle.
4. Use **Build > Build APK(s)**.
5. O APK de depuração normalmente aparece em `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfira o APK ao celular, toque nele e siga as instruções de instalação.

## Importante
Este é o código-fonte, não um APK já compilado. Não foi compilado nem testado em aparelho físico nesta sessão. O recurso de continuar do ponto salvo usa o botão **Salvar posição**; para links online, use URL direta para o arquivo de vídeo, não páginas de streaming. Legendas dependem do formato/origem e podem exigir reabrir o vídeo. A reprodução em segundo plano depende das políticas/permissões da versão Android.
