package com.visionplay.app

import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.VideoView
import android.widget.MediaController
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var video: VideoView
    private lateinit var urlInput: EditText
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("vision_play", MODE_PRIVATE) }
    private val pickVideo = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = 0
        buildUi()
        val last = prefs.getString("last_url", "") ?: ""
        if (last.isNotBlank()) urlInput.setText(last)
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(Color.rgb(10, 10, 12))
        }
        val title = TextView(this).apply {
            text = "VISION PLAY"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            letterSpacing = 0.12f
            setPadding(0, dp(8), 0, dp(12))
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        video = VideoView(this).apply {
            setBackgroundColor(Color.BLACK)
            setMediaController(MediaController(this@MainActivity))
        }
        root.addView(video, LinearLayout.LayoutParams(-1, 0, 1f))

        status = TextView(this).apply {
            text = "Escolha um vídeo do celular ou cole um link compatível."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(10), 0, dp(8))
        }
        root.addView(status)

        urlInput = EditText(this).apply {
            hint = "https://... link direto do vídeo"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 14f
            singleLine = true
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.rgb(35, 35, 39))
        }
        root.addView(urlInput, LinearLayout.LayoutParams(-1, dp(48)))

        val playUrl = makeButton("REPRODUZIR LINK") {
            val raw = urlInput.text.toString().trim()
            if (raw.startsWith("https://") || raw.startsWith("http://")) {
                prefs.edit().putString("last_url", raw).apply()
                playUri(Uri.parse(raw), "Reproduzindo link")
            } else {
                toast("Cole um link http:// ou https:// válido.")
            }
        }
        root.addView(playUrl, buttonParams())

        val openLocal = makeButton("ABRIR VÍDEO DO CELULAR") {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "video/*"
            }
            startActivityForResult(intent, pickVideo)
        }
        root.addView(openLocal, buttonParams())

        val favorite = makeButton("REABRIR ÚLTIMO LINK") {
            val saved = prefs.getString("last_url", "") ?: ""
            if (saved.isNotBlank()) playUri(Uri.parse(saved), "Abrindo último link")
            else toast("Ainda não há link salvo.")
        }
        root.addView(favorite, buttonParams())

        val fullscreen = makeButton("TELA CHEIA") { toggleFullscreen() }
        root.addView(fullscreen, buttonParams())

        setContentView(root)
    }

    private fun playUri(uri: Uri, message: String) {
        try {
            status.text = message
            video.setVideoURI(uri)
            video.setOnPreparedListener { mp ->
                mp.isLooping = false
                video.start()
                status.text = "Reproduzindo"
            }
            video.setOnErrorListener { _, _, _ ->
                status.text = "Não foi possível reproduzir. Use um link direto compatível."
                toast("Formato ou link não compatível.")
                true
            }
        } catch (e: Exception) {
            toast("Não foi possível abrir esse vídeo.")
        }
    }

    @Deprecated("Deprecated in Android API but used for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickVideo && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            playUri(uri, "Vídeo local selecionado")
        }
    }

    private fun toggleFullscreen() {
        val full = (window.decorView.systemUiVisibility and View.SYSTEM_UI_FLAG_FULLSCREEN) == 0
        if (full) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        } else {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            window.decorView.systemUiVisibility = 0
            window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        }
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 13f
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(42, 42, 48))
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun buttonParams() = LinearLayout.LayoutParams(-1, dp(48)).apply {
        topMargin = dp(7)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
