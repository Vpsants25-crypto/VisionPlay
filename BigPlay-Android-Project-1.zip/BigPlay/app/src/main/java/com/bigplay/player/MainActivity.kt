package com.bigplay.player

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

private val Background = Color(0xFF101114)
private val SurfaceDark = Color(0xFF1B1D22)
private val Accent = Color(0xFFFF6B24)

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent {
            BigPlayApp(
                player = player!!,
                onError = { message ->
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                }
            )
        }
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BigPlayApp(player: ExoPlayer, onError: (String) -> Unit) {
    val context = LocalContext.current
    var url by remember { mutableStateOf("") }
    var showUrlDialog by remember { mutableStateOf(false) }
    var currentTitle by remember { mutableStateOf("Nenhum vídeo selecionado") }
    var isPlaying by remember { mutableStateOf(false) }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }
            override fun onPlayerError(error: PlaybackException) {
                onError("Não foi possível reproduzir este vídeo. Verifique o link ou o formato.")
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
                // Alguns provedores não oferecem permissão persistente; a URI ainda pode funcionar.
            }
            currentTitle = uri.lastPathSegment?.substringAfterLast('/') ?: "Vídeo local"
            player.setMediaItem(MediaItem.fromUri(uri))
            player.prepare()
            player.playWhenReady = true
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Background,
            surface = SurfaceDark,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(containerColor = Background) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(Background)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .background(Accent, RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null,
                            tint = Color.White, modifier = Modifier.size(34.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("BIG PLAY", fontSize = 23.sp, fontWeight = FontWeight.Black,
                            color = Color.White, letterSpacing = 1.5.sp)
                        Text("Seu vídeo. Do seu jeito.", color = Color.LightGray, fontSize = 12.sp)
                    }
                }

                AndroidView(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .background(Color.Black),
                    factory = { viewContext ->
                        PlayerView(viewContext).apply {
                            this.player = player
                            useController = true
                            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                            setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
                        }
                    },
                    update = { it.player = player }
                )

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 20.dp, vertical = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("REPRODUZINDO", color = Accent, fontSize = 11.sp,
                        fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                    Text(currentTitle, color = Color.White, fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold, maxLines = 2)
                    Text(
                        if (isPlaying) "Reprodução em andamento" else "Escolha um vídeo para começar",
                        color = Color.Gray, fontSize = 13.sp
                    )

                    Spacer(Modifier.height(4.dp))

                    Button(
                        onClick = { filePicker.launch(arrayOf("video/*")) },
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent)
                    ) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null)
                        Spacer(Modifier.width(10.dp))
                        Text("Abrir vídeo do celular", fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = { showUrlDialog = true },
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                    ) {
                        Icon(Icons.Default.Link, contentDescription = null)
                        Spacer(Modifier.width(10.dp))
                        Text("Reproduzir por URL")
                    }

                    Spacer(Modifier.weight(1f))
                    Text(
                        "Compatibilidade depende do formato do vídeo e do servidor. URLs HTTPS diretas para arquivos de mídia são as mais indicadas.",
                        color = Color.Gray, fontSize = 11.sp, lineHeight = 16.sp
                    )
                }
            }
        }

        if (showUrlDialog) {
            AlertDialog(
                onDismissRequest = { showUrlDialog = false },
                title = { Text("Reproduzir por URL") },
                text = {
                    OutlinedTextField(
                        value = url,
                        onValueChange = { url = it },
                        label = { Text("Link direto do vídeo") },
                        placeholder = { Text("https://exemplo.com/video.mp4") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        val trimmed = url.trim()
                        if (trimmed.startsWith("https://", true) ||
                            trimmed.startsWith("http://", true)) {
                            currentTitle = trimmed.substringAfterLast('/').ifBlank { trimmed }
                            player.setMediaItem(MediaItem.fromUri(trimmed))
                            player.prepare()
                            player.playWhenReady = true
                            showUrlDialog = false
                        } else {
                            onError("Informe uma URL começando com http:// ou https://.")
                        }
                    }) { Text("Reproduzir", color = Accent) }
                },
                dismissButton = {
                    TextButton(onClick = { showUrlDialog = false }) { Text("Cancelar") }
                },
                containerColor = SurfaceDark,
                titleContentColor = Color.White,
                textContentColor = Color.White
            )
        }
    }
}
